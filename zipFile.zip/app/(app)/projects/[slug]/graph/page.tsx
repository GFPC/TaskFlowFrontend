"use client"

import { useParams, useRouter } from "next/navigation"
import useSWR from "swr"
import { useCallback, useEffect, useMemo, useState } from "react"
import ReactFlow, {
  Background,
  Controls,
  MiniMap,
  useNodesState,
  useEdgesState,
  addEdge,
  MarkerType,
  type Connection,
  type Node,
  type Edge,
  Panel,
} from "reactflow"
import "reactflow/dist/style.css"
import { tasks as tasksApi, type GraphData, type GraphNode, type GraphEdge } from "@/lib/api"
import { Button } from "@/components/ui/button"
import { ArrowLeft, Plus, Loader2, Save } from "lucide-react"
import { TaskNode } from "@/components/graph/task-node"
import { TaskDetailDialog } from "@/components/graph/task-detail-dialog"
import { CreateTaskDialog } from "@/components/graph/create-task-dialog"
import { toast } from "sonner"

const nodeTypes = { taskNode: TaskNode }

function graphToNodes(graphData: GraphData): Node[] {
  return graphData.nodes.map((n) => ({
    id: n.id,
    type: "taskNode",
    position: n.position,
    data: n.data,
  }))
}

function graphToEdges(graphData: GraphData): Edge[] {
  return graphData.edges.map((e) => ({
    id: e.id,
    source: e.source,
    target: e.target,
    animated: e.animated ?? true,
    label: e.label,
    markerEnd: { type: MarkerType.ArrowClosed },
    style: { stroke: "hsl(var(--primary))" },
  }))
}

export default function GraphPage() {
  const params = useParams()
  const router = useRouter()
  const slug = params.slug as string

  const { data: graphData, mutate } = useSWR(`graph-${slug}`, () =>
    tasksApi.graph(slug)
  )

  const [nodes, setNodes, onNodesChange] = useNodesState([])
  const [edges, setEdges, onEdgesChange] = useEdgesState([])
  const [selectedTask, setSelectedTask] = useState<any>(null)
  const [showCreate, setShowCreate] = useState(false)

  useEffect(() => {
    if (graphData) {
      setNodes(graphToNodes(graphData))
      setEdges(graphToEdges(graphData))
    }
  }, [graphData, setNodes, setEdges])

  const onConnect = useCallback(
    async (connection: Connection) => {
      if (!connection.source || !connection.target) return
      try {
        await tasksApi.createDependency(slug, Number(connection.source), {
          target_task_id: Number(connection.target),
          dependency_type: "blocks",
        })
        setEdges((eds) =>
          addEdge(
            {
              ...connection,
              animated: true,
              markerEnd: { type: MarkerType.ArrowClosed },
              style: { stroke: "hsl(var(--primary))" },
            },
            eds
          )
        )
        toast.success("Зависимость добавлена")
        mutate()
      } catch {
        toast.error("Ошибка: возможен цикл зависимостей")
      }
    },
    [slug, setEdges, mutate]
  )

  const onNodeClick = useCallback((_: any, node: Node) => {
    setSelectedTask(node.data)
  }, [])

  const handleSavePositions = useCallback(async () => {
    const updatedGraph: GraphData = {
      nodes: nodes.map((n) => ({
        id: n.id,
        type: n.type || "taskNode",
        data: n.data,
        position: n.position,
      })),
      edges: edges.map((e) => ({
        id: e.id,
        source: e.source,
        target: e.target,
        animated: e.animated,
        label: typeof e.label === "string" ? e.label : undefined,
      })),
    }
    try {
      await tasksApi.saveGraph(slug, updatedGraph)
      toast.success("Граф сохранён")
    } catch {
      toast.error("Ошибка сохранения")
    }
  }, [slug, nodes, edges])

  if (!graphData) {
    return (
      <div className="flex items-center justify-center h-[80vh]">
        <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
      </div>
    )
  }

  return (
    <div className="h-[calc(100vh-4rem)]">
      <ReactFlow
        nodes={nodes}
        edges={edges}
        onNodesChange={onNodesChange}
        onEdgesChange={onEdgesChange}
        onConnect={onConnect}
        onNodeClick={onNodeClick}
        nodeTypes={nodeTypes}
        fitView
        className="bg-background"
      >
        <Background gap={20} size={1} />
        <Controls />
        <MiniMap
          nodeColor={() => "hsl(var(--primary))"}
          maskColor="hsl(var(--background) / 0.7)"
        />
        <Panel position="top-left" className="flex gap-2">
          <Button variant="outline" size="sm" onClick={() => router.push(`/projects/${slug}`)}>
            <ArrowLeft className="h-4 w-4 mr-1" />
            Назад
          </Button>
          <Button size="sm" onClick={() => setShowCreate(true)}>
            <Plus className="h-4 w-4 mr-1" />
            Задача
          </Button>
          <Button variant="secondary" size="sm" onClick={handleSavePositions}>
            <Save className="h-4 w-4 mr-1" />
            Сохранить
          </Button>
        </Panel>
      </ReactFlow>

      {selectedTask && (
        <TaskDetailDialog
          task={selectedTask}
          projectSlug={slug}
          open={!!selectedTask}
          onClose={() => setSelectedTask(null)}
          onUpdate={() => mutate()}
        />
      )}

      <CreateTaskDialog
        projectSlug={slug}
        open={showCreate}
        onClose={() => setShowCreate(false)}
        onCreate={() => {
          mutate()
          setShowCreate(false)
        }}
      />
    </div>
  )
}
