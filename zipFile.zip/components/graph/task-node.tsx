"use client";

import { memo } from "react";
import { Handle, Position, type NodeProps } from "@xyflow/react";
import { Badge } from "@/components/ui/badge";
import { Clock, User, Flag, CheckCircle2, AlertCircle, Play } from "lucide-react";
import { cn } from "@/lib/utils";

interface TaskNodeData {
  id: number;
  name: string;
  status: string;
  status_color: string;
  assignee?: string;
  creator?: string;
  priority: number;
  deadline?: string;
  is_ready: boolean;
  [key: string]: unknown;
}

function TaskNodeComponent({ data, selected }: NodeProps<{ data: TaskNodeData } & Record<string, unknown>>) {
  const nodeData = (data as unknown as { data: TaskNodeData }).data ?? data as unknown as TaskNodeData;

  const statusColors: Record<string, string> = {
    todo: "border-l-muted-foreground",
    in_progress: "border-l-primary",
    review: "border-l-warning",
    completed: "border-l-success",
    blocked: "border-l-destructive",
  };

  const statusIcons: Record<string, React.ReactNode> = {
    todo: <Flag className="h-3 w-3" />,
    in_progress: <Play className="h-3 w-3" />,
    review: <AlertCircle className="h-3 w-3" />,
    completed: <CheckCircle2 className="h-3 w-3" />,
    blocked: <AlertCircle className="h-3 w-3" />,
  };

  const statusLabels: Record<string, string> = {
    todo: "К выполнению",
    in_progress: "В работе",
    review: "На проверке",
    completed: "Выполнена",
    blocked: "Заблокирована",
  };

  const priorityColors: Record<number, string> = {
    0: "text-muted-foreground",
    1: "text-warning",
    2: "text-destructive",
  };

  const isDeadlineSoon = nodeData.deadline
    ? new Date(nodeData.deadline).getTime() - Date.now() < 24 * 60 * 60 * 1000
    : false;

  const isOverdue = nodeData.deadline
    ? new Date(nodeData.deadline).getTime() < Date.now()
    : false;

  return (
    <div
      className={cn(
        "rounded-lg border border-border bg-card shadow-md w-56 overflow-hidden border-l-4 transition-all",
        statusColors[nodeData.status] || "border-l-muted",
        selected && "ring-2 ring-primary shadow-lg",
        !nodeData.is_ready && nodeData.status !== "completed" && "opacity-70",
        nodeData.is_ready && nodeData.status === "todo" && "ring-1 ring-success/50"
      )}
    >
      <Handle type="target" position={Position.Top} className="!bg-primary !w-2.5 !h-2.5 !border-2 !border-card" />

      <div className="p-3">
        {/* Status row */}
        <div className="flex items-center justify-between mb-1.5">
          <Badge
            variant="outline"
            className="text-[10px] gap-1 px-1.5 py-0 font-normal"
            style={{ color: nodeData.status_color }}
          >
            {statusIcons[nodeData.status]}
            {statusLabels[nodeData.status] || nodeData.status}
          </Badge>
          {nodeData.is_ready && nodeData.status === "todo" && (
            <span className="text-[10px] font-medium text-success">Готова</span>
          )}
        </div>

        {/* Name */}
        <p className={cn(
          "text-sm font-medium text-card-foreground leading-snug line-clamp-2",
          nodeData.status === "completed" && "line-through opacity-75"
        )}>
          {nodeData.name}
        </p>

        {/* Meta */}
        <div className="flex items-center gap-2 mt-2 text-[10px] text-muted-foreground">
          {nodeData.assignee && (
            <span className="flex items-center gap-0.5 truncate">
              <User className="h-2.5 w-2.5 shrink-0" />
              {nodeData.assignee}
            </span>
          )}
          {nodeData.deadline && (
            <span className={cn(
              "flex items-center gap-0.5",
              isOverdue && "text-destructive font-medium",
              isDeadlineSoon && !isOverdue && "text-warning font-medium"
            )}>
              <Clock className="h-2.5 w-2.5 shrink-0" />
              {new Date(nodeData.deadline).toLocaleDateString("ru", { day: "numeric", month: "short" })}
            </span>
          )}
          <span className={cn("flex items-center gap-0.5 ml-auto", priorityColors[nodeData.priority])}>
            <Flag className="h-2.5 w-2.5" />
            {nodeData.priority === 0 ? "Н" : nodeData.priority === 1 ? "С" : "В"}
          </span>
        </div>
      </div>

      <Handle type="source" position={Position.Bottom} className="!bg-primary !w-2.5 !h-2.5 !border-2 !border-card" />
    </div>
  );
}

export const TaskNode = memo(TaskNodeComponent);
